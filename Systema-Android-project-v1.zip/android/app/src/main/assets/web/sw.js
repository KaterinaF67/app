const CACHE='system-tracker-v3';
const FILES=['./','./index.html','./styles.css?v=3','./app.js?v=3','./manifest.webmanifest','./assets/app-icon.svg','./assets/backgrounds/noise.svg','./assets/backgrounds/grid.svg','./assets/backgrounds/navy.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
    const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));return response;
  }).catch(()=>caches.match('./index.html'))));
});
