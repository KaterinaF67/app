# Сборка Android

## Через Android Studio
1. Откройте папку `android` как проект.
2. Дождитесь Gradle Sync.
3. Выберите Build → Build APK(s).
4. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Через GitHub Actions
Готовый workflow находится в `.github/workflows/build-apps.yml` в корне общего проекта.

## Хранение данных
WebView DOM Storage хранит данные в закрытом каталоге приложения. Удаление приложения удалит локальную базу, поэтому периодически выгружайте JSON.
